import { LightningElement, wire, track } from 'lwc';
import searchListings from '@salesforce/apex/PropertyListingController.searchListings';
import getBoroughOptions from '@salesforce/apex/PropertyListingController.getBoroughOptions';
import getPropertyTypeOptions from '@salesforce/apex/PropertyListingController.getPropertyTypeOptions';
import getStatusOptions from '@salesforce/apex/PropertyListingController.getStatusOptions';

export default class PropertyListingBrowser extends LightningElement {
    @track listings = [];
    @track boroughOptions = [{ label: 'All Boroughs', value: '' }];
    @track propertyTypeOptions = [{ label: 'All Types', value: '' }];
    @track statusOptions = [{ label: 'All Statuses', value: '' }];

    borough = '';
    propertyType = '';
    status = 'Available';
    minPrice;
    maxPrice;
    minBedrooms;

    isLoading = false;
    errorMessage;

    connectedCallback() {
        this.loadPicklists();
        this.runSearch();
    }

    async loadPicklists() {
        try {
            const [boroughs, types, statuses] = await Promise.all([
                getBoroughOptions(),
                getPropertyTypeOptions(),
                getStatusOptions()
            ]);
            this.boroughOptions = [
                { label: 'All Boroughs', value: '' },
                ...boroughs.map((b) => ({ label: b, value: b }))
            ];
            this.propertyTypeOptions = [
                { label: 'All Types', value: '' },
                ...types.map((t) => ({ label: t, value: t }))
            ];
            this.statusOptions = [
                { label: 'All Statuses', value: '' },
                ...statuses.map((s) => ({ label: s, value: s }))
            ];
        } catch (error) {
            this.errorMessage = this.reduceError(error);
        }
    }

    async runSearch() {
        this.isLoading = true;
        this.errorMessage = undefined;
        try {
            const results = await searchListings({
                borough: this.borough || null,
                propertyType: this.propertyType || null,
                minPrice: this.minPrice || null,
                maxPrice: this.maxPrice || null,
                minBedrooms: this.minBedrooms || null,
                status: this.status || null
            });
            this.listings = results.map((r) => ({
                ...r,
                formattedPrice: this.formatPrice(r.Price__c)
            }));
        } catch (error) {
            this.errorMessage = this.reduceError(error);
            this.listings = [];
        } finally {
            this.isLoading = false;
        }
    }

    formatPrice(price) {
        if (price === null || price === undefined) return '';
        return new Intl.NumberFormat('en-GB', {
            style: 'currency',
            currency: 'GBP',
            maximumFractionDigits: 0
        }).format(price);
    }

    reduceError(error) {
        if (error && error.body && error.body.message) {
            return error.body.message;
        }
        return 'An unexpected error occurred while loading listings.';
    }

    get hasListings() {
        return this.listings && this.listings.length > 0;
    }

    get resultCountLabel() {
        const count = this.listings ? this.listings.length : 0;
        return `${count} propert${count === 1 ? 'y' : 'ies'} found`;
    }

    handleBoroughChange(event) {
        this.borough = event.detail.value;
    }

    handlePropertyTypeChange(event) {
        this.propertyType = event.detail.value;
    }

    handleStatusChange(event) {
        this.status = event.detail.value;
    }

    handleMinPriceChange(event) {
        this.minPrice = event.detail.value;
    }

    handleMaxPriceChange(event) {
        this.maxPrice = event.detail.value;
    }

    handleMinBedroomsChange(event) {
        this.minBedrooms = event.detail.value;
    }

    handleSearch() {
        this.runSearch();
    }

    handleReset() {
        this.borough = '';
        this.propertyType = '';
        this.status = 'Available';
        this.minPrice = undefined;
        this.maxPrice = undefined;
        this.minBedrooms = undefined;
        this.runSearch();
    }
}
