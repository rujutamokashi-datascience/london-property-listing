import { LightningElement, api } from 'lwc';

const STATUS_VARIANT = {
    Available: 'success',
    'Under Offer': 'warning',
    Sold: 'error',
    Let: 'inverse',
    Withdrawn: 'error'
};

export default class PropertyCard extends LightningElement {
    @api listing;
    imageErrorHandled = false;

    get imageUrl() {
        const imageUrl = this.listing?.Image_URL__c?.trim();
        return imageUrl || this.fallbackImageUrl;
    }

    get fallbackImageUrl() {
        const address = (this.listing?.Address__c || 'Property Listing').replace(/&/g, '&amp;');
        const borough = (this.listing?.Borough__c || 'London').replace(/&/g, '&amp;');
        const type = (this.listing?.Property_Type__c || 'Property').replace(/&/g, '&amp;');
        const price = this.listing?.Price__c != null ? this.formatPrice(this.listing.Price__c) : 'Contact agent';

        const svg = `
            <svg xmlns="http://www.w3.org/2000/svg" width="800" height="600" viewBox="0 0 800 600">
                <defs>
                    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stop-color="#0b5fff" />
                        <stop offset="100%" stop-color="#0f172a" />
                    </linearGradient>
                </defs>
                <rect width="800" height="600" fill="url(#bg)" />
                <rect x="48" y="48" width="704" height="504" rx="28" fill="rgba(255,255,255,0.15)" stroke="rgba(255,255,255,0.35)" />
                <circle cx="640" cy="180" r="120" fill="rgba(255,255,255,0.15)" />
                <path d="M220 420c70-140 190-220 330-220" stroke="rgba(255,255,255,0.35)" stroke-width="10" fill="none" stroke-linecap="round" />
                <text x="80" y="240" font-family="Segoe UI, Arial, sans-serif" font-size="36" font-weight="700" fill="#ffffff">${address}</text>
                <text x="80" y="300" font-family="Segoe UI, Arial, sans-serif" font-size="24" font-weight="500" fill="#dbeafe">${type} · ${borough}</text>
                <text x="80" y="360" font-family="Segoe UI, Arial, sans-serif" font-size="28" font-weight="600" fill="#f8fafc">${price}</text>
                <text x="80" y="420" font-family="Segoe UI, Arial, sans-serif" font-size="20" fill="#bfdbfe">London Property Listing</text>
            </svg>`;

        return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
    }

    handleImageError(event) {
        if (!this.imageErrorHandled) {
            this.imageErrorHandled = true;
            event.target.setAttribute('src', this.fallbackImageUrl);
        }
    }

    formatPrice(price) {
        return new Intl.NumberFormat('en-GB', {
            style: 'currency',
            currency: 'GBP',
            maximumFractionDigits: 0
        }).format(price);
    }

    get statusClass() {
        const variant = STATUS_VARIANT[this.listing?.Listing_Status__c] || 'inverse';
        return `slds-badge slds-theme_${variant}`;
    }

    get bedBathLabel() {
        if (!this.listing) return '';
        const beds = this.listing.Bedrooms__c || 0;
        const baths = this.listing.Bathrooms__c || 0;
        return `${beds} bed · ${baths} bath`;
    }

    get recordUrl() {
        return this.listing ? `/lightning/r/Property_Listing__c/${this.listing.Id}/view` : '#';
    }
}
